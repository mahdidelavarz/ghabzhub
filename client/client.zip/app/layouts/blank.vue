<template>
    <slot/>
</template>